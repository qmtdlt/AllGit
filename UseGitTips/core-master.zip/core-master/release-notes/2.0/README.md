# .NET Core 2.0.0 Release Documents

## Preview 2 (06/28/2017)

- [Release Notes](2.0.0-preview2.md)
- [Known Issues](2.0.0-preview2-known-issues.md)

## Preview 1 (05/10/2017)

- [Release Notes](2.0.0-preview1.md)
- [Known Issues](2.0.0-preview1-known-issues.md)