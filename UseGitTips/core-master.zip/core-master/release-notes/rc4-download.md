.NET Core Tools download
------------------------

Thank you for you interest in .NET Core Tools. We have released v1, so please go to https://dot.net/core to download the released version. 
