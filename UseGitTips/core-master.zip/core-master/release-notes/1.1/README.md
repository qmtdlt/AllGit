# .NET Core 1.1.0 Release Documents

## 1.1 (11/16/2016)

- [Release Notes](1.1.md)
- [Known Issues](1.1-known-issues.md)
- [Commits](1.1-commits.md)
- [Contributors](1.1-contributor-list.md)
- [1.0 - 1.1 Preview 1 API Differences](1.0-1.1-api-diff/1.0-1.1-api-diff.md)


## Preview 1 (10/24/2016)

- [Release Notes](1.1.0-preview1.md)
- [Known Issues](1.1.0-preview1-known-issues.md)
- [Commits](1.1-preview1-commits.md)
- [Contributors](1.1.0-preview1-contibutor-list.md)
- [1.0 - 1.1 Preview 1 API Differences](1.0-1.1-api-diff/1.0-1.1-api-diff.md)